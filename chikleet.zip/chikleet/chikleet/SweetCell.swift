//
//  SweetCell.swift
//  chikleet
//
//  Created by Sansoya Saab on 2019-07-09.
//  Copyright © 2019 Sansoya Saab. All rights reserved.
//

import UIKit

class SweetCell: UITableViewCell {
    
    
    @IBOutlet var text1Label: UILabel!
    
    @IBOutlet var detailLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
