//
//  ViewController.swift
//  chikleet
//
//  Created by Sansoya Saab on 2019-07-03.
//  Copyright © 2019 Sansoya Saab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

