//
//  signIn.swift
//  chikleet
//
//  Created by Sansoya Saab on 2019-07-03.
//  Copyright © 2019 Sansoya Saab. All rights reserved.
//

import UIKit
import  Firebase
import FirebaseAuth

class signInViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var emailField: UITextField!
    
    @IBOutlet var passwordField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailField.delegate = self
        passwordField.delegate = self
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func signIn(_ sender: Any) {
        
        Auth.auth().signIn(withEmail: emailField.text!,
                           password: passwordField.text!) { (user, error) in
                            
                            if error == nil
                            {
                                self.performSegue(withIdentifier: "signedIn", sender: self)
                            }
                            else
                            {
                                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                                
                                alertController.addAction(defaultAction)
                                self.present(alertController, animated: true, completion: nil)
                            }
        }
        
        
    }
    
    
    
    @IBAction func tapGapRecognizer(_ sender: Any) {
        
        
        view.endEditing(true)
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
