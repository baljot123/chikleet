//
//  signUp.swift
//  chikleet
//
//  Created by Sansoya Saab on 2019-07-03.
//  Copyright © 2019 Sansoya Saab. All rights reserved.
//


import UIKit
import Firebase
import FirebaseAuth

class signupViewController: UIViewController , UITextFieldDelegate{
    
    @IBOutlet var email: UITextField!
    
    @IBOutlet var pass1: UITextField!
    
    @IBOutlet var pass2: UITextField!
    
    @IBOutlet var signup: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        email.delegate = self
        pass1.delegate = self
        pass2.delegate = self
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func signUp(_ sender: Any) {
        
        
        if(pass1.text == pass2.text)
        {
            Auth.auth().createUser(withEmail: email.text!, password: pass1.text!) { authResult, error in
                // ...
                if error == nil
                {
                    Auth.auth().signIn(withEmail: self.email.text!,
                                       password: self.pass1.text!) { (user, error) in
                                        
                                        if error == nil
                                        {
                                            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                                            changeRequest?.displayName = "0"
                                            changeRequest?.commitChanges { (error) in
                                                // ...
                                            }
                                            
                                            self.performSegue(withIdentifier: "signIn", sender: self)
                                            
                                        }
                    }
                }
                else
                {
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
            
        }
        else
        {
            let alertController = UIAlertController(title: "Error", message: "Password doesn't match", preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
        
        
    }
    
    
    
    
    @IBAction func tapGapRecognizer(_ sender: Any) {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
